package com.friday.assistant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.UtteranceProgressListener;
import java.util.*;
import java.text.SimpleDateFormat;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.StorageService;
import org.vosk.android.SpeechService;


public class FridayListeningService extends Service implements RecognitionListener {
    private static final String CH = "friday_listening";
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private Handler h = new Handler(Looper.getMainLooper());
    private boolean running = false, speaking = false;
    private String persona = "friday";
    private String language = "en-IN";
    private boolean ttsReady = false;
    private Model offlineModel;
    private org.vosk.android.SpeechService offlineSpeech;
    private boolean offlineReady = false;
    private boolean modelLoading = false;

    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Assistant listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while the assistant listens");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        tts = new TextToSpeech(this, s -> {
            if (s == TextToSpeech.SUCCESS) {
                ttsReady = true;
                configureVoice();
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) {
                        h.post(() -> {
                            speaking = false;
                            if (running) resumeRecognition();
                        });
                    }
                    @Override public void onError(String id) {
                        h.post(() -> {
                            speaking = false;
                            if (running) resumeRecognition();
                        });
                    }
                });
            }
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(this);
        }
    }

    private void loadOfflineModel() {
        if (modelLoading || offlineReady) return;
        modelLoading = true;
        final String asset = language.equals("hi-IN") ? "model-hi" : "model-en";
        final String target = language.equals("hi-IN") ? "friday-model-hi" : "friday-model-en";
        try {
            StorageService.unpack(this, asset, target, model -> {
                offlineModel = model;
                offlineReady = true;
                modelLoading = false;
                if (running && !speaking) startOfflineListening();
            }, exception -> {
                modelLoading = false;
                offlineReady = false;
                android.util.Log.e("FridayOffline", "Offline model load failed; using online recognizer", exception);
                if (running && !speaking) listenOnline();
            });
        } catch (Exception e) {
            modelLoading = false;
            android.util.Log.e("FridayOffline", "Offline model unavailable; using online recognizer", e);
        }
    }

    private void resumeRecognition() {
        if (!running || speaking) return;
        if (offlineReady) startOfflineListening();
        else if (!modelLoading) listenOnline();
    }

    private void startOfflineListening() {
        if (!running || speaking || offlineModel == null || offlineSpeech != null) return;
        try {
            Recognizer recognizer = new Recognizer(offlineModel, 16000.0f);
            offlineSpeech = new org.vosk.android.SpeechService(recognizer, 16000.0f);
            offlineSpeech.startListening(new org.vosk.android.RecognitionListener() {
                @Override public void onPartialResult(String hypothesis) { }
                @Override public void onResult(String hypothesis) { }
                @Override public void onFinalResult(String hypothesis) {
                    h.post(() -> {
                        offlineSpeech = null;
                        String heard = extractVoskText(hypothesis);
                        if (!heard.isEmpty()) handle(heard);
                        if (running && !speaking) h.postDelayed(() -> startOfflineListening(), 500);
                    });
                }
                @Override public void onError(Exception e) {
                    h.post(() -> {
                        android.util.Log.e("FridayOffline", "Offline recognition error", e);
                        stopOfflineSpeech();
                        if (running && !speaking) h.postDelayed(() -> startOfflineListening(), 1000);
                    });
                }
                @Override public void onTimeout() {
                    h.post(() -> {
                        stopOfflineSpeech();
                        if (running && !speaking) h.postDelayed(() -> startOfflineListening(), 300);
                    });
                }
            });
        } catch (Exception e) {
            android.util.Log.e("FridayOffline", "Could not start offline recognition; switching to online", e);
            offlineReady = false;
            listenOnline();
        }
    }

    private String extractVoskText(String json) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            return obj.optString("text", "").trim();
        } catch (Exception e) { return ""; }
    }

    private void stopOfflineSpeech() {
        if (offlineSpeech != null) {
            try { offlineSpeech.stop(); } catch (Exception ignored) {}
            try { offlineSpeech.shutdown(); } catch (Exception ignored) {}
            offlineSpeech = null;
        }
    }

    private void listenOnline() {
        if (!running || speaking || sr == null) return;
        h.postDelayed(() -> {
            if (!running || speaking || sr == null) return;
            try {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                sr.startListening(i);
            } catch (Exception e) { restart(1500); }
        }, 600);
    }

    public int onStartCommand(Intent in, int flags, int id) {
        if (in != null) {
            if (in.hasExtra("persona")) persona = in.getStringExtra("persona");
            if (in.hasExtra("language")) language = in.getStringExtra("language");
        }
        running = true;
        configureVoice();
        if (offlineModel == null && !modelLoading) loadOfflineModel();
        Intent open = new Intent(this, MainActivity.class);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pf |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, pf);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        Notification n = nb.setContentTitle(persona.equals("jarvis") ? "Jarvis is listening" : "Friday is listening")
            .setContentText("Mode: " + (language.equals("hi-IN") ? "Hindi" : "English") + " • say your wake word")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
        startForeground(4401, n);
        listen();
        return START_STICKY;
    }

    private void configureVoice() {
        if (tts == null || !ttsReady) return;
        Locale loc = language.equals("hi-IN") ? new Locale("hi", "IN") : new Locale("en", "IN");
        int result = tts.setLanguage(loc);
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(language.equals("hi-IN") ? new Locale("hi") : new Locale("en", "IN"));
        }
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    String wanted = persona.equals("jarvis") ? "male" : "female";
                    Voice chosen = null;
                    for (Voice v : voices) {
                        if (v.getLocale().getLanguage().equals(language.substring(0, 2))
                            && v.getName().toLowerCase(Locale.ROOT).contains(wanted)
                            && !v.isNetworkConnectionRequired()) { chosen = v; break; }
                    }
                    if (chosen == null) {
                        for (Voice v : voices) {
                            if (v.getLocale().getLanguage().equals(language.substring(0, 2))
                                && v.getName().toLowerCase(Locale.ROOT).contains(wanted)) { chosen = v; break; }
                        }
                    }
                    if (chosen != null) tts.setVoice(chosen);
                    else tts.setPitch(persona.equals("jarvis") ? 0.82f : 1.0f);
                }
            } catch (Exception ignored) { tts.setPitch(persona.equals("jarvis") ? 0.82f : 1.0f); }
        } else {
            tts.setPitch(persona.equals("jarvis") ? 0.82f : 1.0f);
        }
    }

    private void listen() {
        if (offlineReady) { startOfflineListening(); return; }
        if (modelLoading) return;
        listenOnline();
    }

    private void listenLegacyRemoved() {
        if (!running || speaking || sr == null) return;
        h.postDelayed(() -> {
            if (!running || speaking || sr == null) return;
            try {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                sr.startListening(i);
            } catch (Exception e) { restart(1500); }
        }, 600);
    }

    private void restart(long d) {
        if (running && !speaking) h.postDelayed(this::listen, d);
    }

    public void onResults(Bundle b) {
        ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (a != null && !a.isEmpty()) handle(a.get(0));
        if (!offlineReady) restart(900);
    }
    public void onError(int e) { if (!offlineReady) restart(e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1800 : 1200); }
    public void onReadyForSpeech(Bundle b) {}
    public void onBeginningOfSpeech() {}
    public void onRmsChanged(float r) {}
    public void onBufferReceived(byte[] b) {}
    public void onEndOfSpeech() {}
    public void onEvent(int e, Bundle b) {}
    public void onPartialResults(Bundle b) {}

    private void handle(String text) {
        String q = text.toLowerCase(Locale.ROOT).trim();
        String wake = persona.equals("jarvis") ? "jarvis" : "friday";
        boolean heardWake = q.contains(wake);
        if (!heardWake) return; // Ignore background audio unless selected wake word is recognized.

        String c = q.replaceFirst(".*\\b" + wake + "\\b", "").trim();
        c = c.replaceAll("^[ ,.!?;:]+", "").trim();
        c = c.replaceAll("(?i)([, ]+)?(over|that's all|that is all|done|बस|बस इतना|हो गया)[.!? ]*$", "").trim();
        if (c.isEmpty()) {
            say(language.equals("hi-IN") ? "जी, बताइए।" : (persona.equals("jarvis") ? "Yes, sir?" : "Yes?"));
            return;
        }
        command(c);
    }

    private void command(String q) {
        String x = q.toLowerCase(Locale.ROOT);
        boolean hi = language.equals("hi-IN");
        if (containsAny(x, "youtube", "यूट्यूब")) url("https://www.youtube.com", hi ? "यूट्यूब खोल रहा हूँ।" : "Opening YouTube.");
        else if (containsAny(x, "google", "search", "browser", "chrome", "गूगल", "सर्च", "ब्राउज़र")) url("https://www.google.com", hi ? "गूगल खोल रहा हूँ।" : "Opening Google.");
        else if (containsAny(x, "whatsapp", "व्हाट्सएप")) pkg("com.whatsapp", hi ? "व्हाट्सएप नहीं मिला।" : "I could not find WhatsApp.");
        else if (containsAny(x, "camera", "photo", "कैमरा", "फोटो")) intent(new Intent("android.media.action.IMAGE_CAPTURE"), hi ? "कैमरा नहीं खोल सका।" : "I could not open Camera.");
        else if (containsAny(x, "settings", "सेटिंग")) intent(new Intent(android.provider.Settings.ACTION_SETTINGS), hi ? "सेटिंग्स नहीं खोल सका।" : "I could not open Settings.");
        else if (containsAny(x, "maps", "navigation", "map", "मैप", "नक्शा")) url("https://maps.google.com", hi ? "मैप्स खोल रहा हूँ।" : "Opening Maps.");
        else if (containsAny(x, "calculator", "कैलकुलेटर", "गणना")) intent(new Intent("android.intent.action.MAIN").addCategory("android.intent.category.APP_CALCULATOR"), hi ? "कैलकुलेटर नहीं खुला।" : "I could not open Calculator.");
        else if (containsAny(x, "clock", "alarm", "घड़ी", "अलार्म")) intent(new Intent("android.intent.action.SHOW_ALARMS"), hi ? "अलार्म खोल रहा हूँ।" : "Opening alarms.");
        else if (containsAny(x, "messages", "sms", "message", "मैसेज", "संदेश")) intent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), hi ? "मैसेज ऐप नहीं खुला।" : "I could not open Messages.");
        else if (containsAny(x, "call", "phone", "dial", "कॉल", "फोन", "फ़ोन")) {
            say(hi ? "फोन डायलर खोल रहा हूँ। कॉल करने से पहले पुष्टि करें।" : "Opening the phone dialer. Please confirm before calling.");
            intent(new Intent(Intent.ACTION_DIAL), hi ? "डायलर नहीं खुला।" : "I could not open the dialer.");
        }
        else if (containsAny(x, "time", "समय", "बजे", "टाइम")) say((hi ? "अभी समय है " : "The time is ") + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date()));
        else if (containsAny(x, "stop listening", "stop assistant", "goodbye", "बंद हो जाओ", "सुनना बंद", "रुक जाओ")) {
            say(hi ? "ठीक है, सुनना बंद कर रहा हूँ।" : "Okay, stopping listening.");
            h.postDelayed(this::stopSelf, 2200);
        }
        else say(hi ? "माफ़ कीजिए, यह कमांड समझ नहीं आया।" : "Sorry, I didn't understand that command.");
    }

    private boolean containsAny(String s, String... terms) {
        for (String t : terms) if (s.contains(t)) return true;
        return false;
    }
    private void url(String u, String msg) { say(msg); intent(new Intent(Intent.ACTION_VIEW, Uri.parse(u)), "Could not open that link."); }
    private void pkg(String p, String f) { Intent i = getPackageManager().getLaunchIntentForPackage(p); if (i == null) say(f); else intent(i, f); }
    private void intent(Intent i, String f) { try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); } catch (Exception e) { say(f); } }
    private void say(String m) {
        if (tts == null || !ttsReady) return;
        speaking = true;
        try { if (sr != null) sr.cancel(); } catch (Exception ignored) {}
        stopOfflineSpeech();
        String utteranceId = "assistant" + System.currentTimeMillis();
        int result = tts.speak(m, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
        if (result == TextToSpeech.ERROR) {
            speaking = false;
            restart(1200);
        }
    }
    public IBinder onBind(Intent i) { return null; }
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (sr != null) { sr.cancel(); sr.destroy(); }
        stopOfflineSpeech();
        if (offlineModel != null) { try { offlineModel.close(); } catch (Exception ignored) {} }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        stopForeground(true);
        super.onDestroy();
    }
}
