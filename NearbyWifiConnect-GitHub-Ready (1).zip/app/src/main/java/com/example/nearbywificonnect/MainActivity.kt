package com.example.nearbywificonnect

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.*
import android.net.wifi.ScanResult
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var wifi: WifiManager
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val permissionRequest = 41
    private var callback: ConnectivityManager.NetworkCallback? = null
    private var retryNetwork: ScanResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 12) }
        root.addView(TextView(this).apply { text = "Nearby Wi-Fi Connect"; textSize = 24f })
        root.addView(TextView(this).apply { text = "Choose a network you are authorized to use, then enter its password."; textSize = 14f })
        root.addView(Button(this).apply { text = "Scan nearby networks"; setOnClickListener { if (hasPermissions()) scan() else requestPermissions() } })
        status = TextView(this).apply { text = "Ready to scan"; textSize = 14f; setPadding(0, 12, 0, 12) }
        root.addView(status)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (hasPermissions()) scan() else requestPermissions()
    }

    private fun hasPermissions(): Boolean {
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val nearby = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
        return fine && nearby
    }

    private fun requestPermissions() {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        requestPermissions(p.toTypedArray(), permissionRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) scan()
        else if (requestCode == permissionRequest) status.text = "Allow nearby Wi-Fi permission to scan. You can also use Android Wi-Fi Settings."
    }

    @Suppress("DEPRECATION")
    private fun scan() {
        if (!wifi.isWifiEnabled) { status.text = "Turn Wi-Fi on, then scan again."; startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); return }
        status.text = "Scanning… Android may limit scan frequency."
        val started = try { wifi.startScan() } catch (_: SecurityException) { false }
        window.decorView.postDelayed({
            val results = try { wifi.scanResults } catch (_: SecurityException) { emptyList() }
            showNetworks(results)
            if (results.isEmpty()) status.text = if (started) "No results yet. Enable Location services and retry." else "Android limited this scan. Try again later."
        }, 1200)
    }

    private fun showNetworks(results: List<ScanResult>) {
        list.removeAllViews()
        val networks = results.filter { it.SSID.isNotBlank() }.distinctBy { it.SSID }.sortedByDescending { it.level }
        if (networks.isEmpty()) { status.text = "No visible networks found. Check Wi-Fi and Location settings."; return }
        status.text = "${networks.size} network(s) found. Select one."
        networks.forEach { net ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
            box.addView(TextView(this).apply { text = net.SSID; textSize = 18f })
            box.addView(TextView(this).apply { text = "Signal: ${when { net.level >= -55 -> "Strong"; net.level >= -67 -> "Good"; net.level >= -75 -> "Fair"; else -> "Weak" }}" })
            box.addView(Button(this).apply { text = "Select / Connect"; setOnClickListener { askPassword(net) } })
            list.addView(box, ViewGroup.LayoutParams(-1, -2))
        }
    }

    private fun askPassword(net: ScanResult, retryMessage: String? = null) {
        retryNetwork = net
        val secured = net.capabilities.contains("PSK") || net.capabilities.contains("SAE") || net.capabilities.contains("WEP") || net.capabilities.contains("EAP")
        val input = EditText(this).apply { hint = if (secured) "Wi-Fi password" else "Password (if required)"; inputType = 129 }
        android.app.AlertDialog.Builder(this)
            .setTitle(if (retryMessage == null) "Connect to ${net.SSID}" else "Password incorrect or connection failed")
            .setMessage(retryMessage ?: "Only connect to a network you have permission to use.")
            .setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Connect") { _, _ ->
                val pass = input.text.toString()
                if (secured && pass.isBlank()) {
                    Toast.makeText(this, "Enter the Wi-Fi password", Toast.LENGTH_SHORT).show()
                    askPassword(net, "Please enter the Wi-Fi password and try again.")
                } else connect(net.SSID, pass, !secured, net)
            }.show()
    }

    @Suppress("DEPRECATION")
    private fun connect(ssid: String, password: String, open: Boolean, selectedNetwork: ScanResult? = retryNetwork) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val b = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (!open) {
                try { b.setWpa2Passphrase(password) } catch (_: IllegalArgumentException) { status.text = "Unsupported password/security type for this starter app."; return }
            }
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(b.build()).build()
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            callback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            status.text = "Requesting Wi-Fi. Android may show a system approval prompt."
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { runOnUiThread { status.text = "Connected to $ssid for this app. Android controls system-wide routing." } }
                override fun onUnavailable() {
                    runOnUiThread {
                        status.text = "Connection failed. The password may be incorrect, or Android may have declined the request."
                        // Android does not expose a definitive wrong-password reason here.
                        // Reopen the password dialog automatically so the user need not reselect the network.
                        val network = selectedNetwork
                        if (network != null && !isFinishing && !isDestroyed) {
                            window.decorView.postDelayed({
                                if (!isFinishing && !isDestroyed) {
                                    askPassword(network, "Could not connect. Check the password and enter it again.")
                                }
                            }, 350)
                        }
                    }
                }
                override fun onLost(network: Network) { runOnUiThread { status.text = "Connection lost." } }
            }
            callback = cb
            try { cm.requestNetwork(req, cb) } catch (_: Exception) { status.text = "Could not request connection. Use Wi-Fi Settings."; startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        } else {
            try {
                val config = WifiConfiguration().apply {
                    SSID = "\"$ssid\""
                    if (open) allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE) else preSharedKey = "\"$password\""
                }
                val id = wifi.addNetwork(config)
                val ok = id >= 0 && wifi.enableNetwork(id, true) && wifi.reconnect()
                status.text = if (ok) "Connection requested for $ssid." else "Could not connect. Check password or use Wi-Fi Settings."
            } catch (_: SecurityException) { status.text = "Android denied connection access. Opening Wi-Fi Settings."; startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        callback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
    }
}
