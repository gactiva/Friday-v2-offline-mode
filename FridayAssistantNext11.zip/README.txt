Friday/Jarvis Assistant - Version 10 source

New in this version:
- Adds Vosk offline speech recognition for English and Hindi.
- GitHub Actions downloads both small Vosk models and packages them inside the APK assets.
- Uses offline recognition when the selected language model loads successfully.
- Falls back to Android SpeechRecognizer (which may use an internet connection) if offline model loading or startup fails.
- Keeps separate Friday/Jarvis personality and selected English/Hindi mode.
- This is speech recognition offline/online fallback, not a fully offline AI chatbot. App-opening commands work offline; web pages and online services need internet.
- APK will be larger because both offline models are bundled.

Build:
- Upload FridayAssistantNext11.zip to the repository.
- In the repository's active workflow, change the extraction line to:
  unzip -o FridayAssistantNext11.zip -d project
- Add a step that downloads/unpacks both Vosk models into app/src/main/assets/model-en and app/src/main/assets/model-hi before the Gradle build (the workflow inside this ZIP shows the required step).
- Build using GitHub Actions and test before replacing the previous APK.

Limitations:
- Source has not been compiled or device-tested here.
- Offline recognition accuracy depends on the small Vosk models and microphone/noise conditions.
- Male/female TTS voice availability depends on installed phone voices.
- Background listening uses microphone access; stop the service when not needed.
