# Nearby Wi-Fi Connect

Android starter project to scan visible Wi-Fi networks and request connection after the user enters a password.

- Minimum Android API 26 (Android 8.0+).
- Scanning requires runtime location permission and may require Location services enabled. Android limits scan frequency.
- Android 10+ uses `WifiNetworkSpecifier`, so Android may show a system approval dialog and the requested network may be scoped to this app rather than becoming the phone's default Wi-Fi for every app. This is an Android security restriction, not an app bug.
- Android 8.0/8.1 uses legacy Wi-Fi configuration APIs; some manufacturers/versions may restrict them.
- This app cannot reveal saved passwords or bypass network security. Use it only on networks you are authorized to access.
- This is a starter project; it has not been built/tested on a physical device and is not ready to claim Play Store approval.

Build with JDK 17 and Android SDK 36 using Android Studio, or run the included GitHub Actions workflow to create a debug APK artifact.
